package com.example.ella.colorstest;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.Spinner;
import android.widget.Switch;

public class MainActivity extends AppCompatActivity {
    private Switch switch2Dark;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        final Context context = this;
        SharedPreferences sharedPref = context.getSharedPreferences(
                getString(R.string.preference_file_key), Context.MODE_PRIVATE);
        int colorSetID = sharedPref.getInt(getString(R.string.colorSetChangeKey), R.style.AppTheme);
        boolean darkMode = sharedPref.getBoolean(getString(R.string.darkModeEnabled), false);

        if (darkMode) {
            setTheme(R.style.DarkMode);
        } else {
            setTheme(colorSetID);
        }
        setContentView(R.layout.activity_main);
        Snackbar mySnackbar = null;
        if(darkMode){
            mySnackbar = Snackbar.make(findViewById(R.id.myCoordinatorLayout),
                    R.string.colorSetD, Snackbar.LENGTH_SHORT);
        } else {
            switch (colorSetID) {
                case R.style.AppTheme:
                    mySnackbar = Snackbar.make(findViewById(R.id.myCoordinatorLayout),
                            R.string.colorSet0, Snackbar.LENGTH_SHORT);
                    break;
                case R.style.PinkMode:
                    mySnackbar = Snackbar.make(findViewById(R.id.myCoordinatorLayout),
                            R.string.colorSet1, Snackbar.LENGTH_SHORT);
                    break;
                case R.style.GreenMode:
                    mySnackbar = Snackbar.make(findViewById(R.id.myCoordinatorLayout),
                            R.string.colorSet2, Snackbar.LENGTH_SHORT);
                    break;
                case R.style.BlueMode:
                    mySnackbar = Snackbar.make(findViewById(R.id.myCoordinatorLayout),
                            R.string.colorSet3, Snackbar.LENGTH_SHORT);
                    break;
                case R.style.RedMode:
                    mySnackbar = Snackbar.make(findViewById(R.id.myCoordinatorLayout),
                            R.string.colorSet4, Snackbar.LENGTH_SHORT);
                    break;
                case R.style.PurpleMode:
                    mySnackbar = Snackbar.make(findViewById(R.id.myCoordinatorLayout),
                            R.string.colorSet5, Snackbar.LENGTH_SHORT);
                    break;
                case R.style.YellowMode:
                    mySnackbar = Snackbar.make(findViewById(R.id.myCoordinatorLayout),
                            R.string.colorSet6, Snackbar.LENGTH_SHORT);
                    break;
            }
        }
        mySnackbar.setAction(R.string.OK, new View.OnClickListener() {
            @Override
            public void onClick(View v) {
            }
        });
        mySnackbar.show();
        switch2Dark = (Switch) findViewById(R.id.switch1);
        switch2Dark.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                SharedPreferences sharedPref = context.getSharedPreferences(
                        getString(R.string.preference_file_key), Context.MODE_PRIVATE);
                SharedPreferences.Editor editor = sharedPref.edit();
                editor.putBoolean(getString(R.string.darkModeEnabled), switch2Dark.isChecked());
                editor.commit();
                recreate();
            }
        });
        final Spinner staticSpinner = (Spinner) findViewById(R.id.spinner);

        //get the spinner from the xml.
        ArrayAdapter<CharSequence> staticAdapter = ArrayAdapter
                .createFromResource(this, R.array.dropdownEntries,
                        android.R.layout.simple_spinner_item);

        //    // Specify the layout to use when the list of choices appears
        staticAdapter
                .setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        //    // Apply the adapter to the spinner
        staticSpinner.setAdapter(staticAdapter);
        staticSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                Snackbar mySnackbar = null;
                SharedPreferences sharedPref = context.getSharedPreferences(
                        getString(R.string.preference_file_key), Context.MODE_PRIVATE);
                SharedPreferences.Editor editor = sharedPref.edit();
                Log.d("DROPDOWN", position + " is selected");
                switch (position) {
                    case 1:
                        mySnackbar = Snackbar.make(findViewById(R.id.myCoordinatorLayout),
                                R.string.colorSet0, Snackbar.LENGTH_SHORT);
                        editor.putInt(getString(R.string.colorSetChangeKey), R.style.AppTheme);
                        break;
                    case 2:
                        mySnackbar = Snackbar.make(findViewById(R.id.myCoordinatorLayout),
                                R.string.colorSet1, Snackbar.LENGTH_SHORT);
                        editor.putInt(getString(R.string.colorSetChangeKey), R.style.PinkMode);
                        break;
                    case 3:
                        mySnackbar = Snackbar.make(findViewById(R.id.myCoordinatorLayout),
                                R.string.colorSet2, Snackbar.LENGTH_SHORT);
                        editor.putInt(getString(R.string.colorSetChangeKey), R.style.GreenMode);
                        break;
                    case 4:
                        mySnackbar = Snackbar.make(findViewById(R.id.myCoordinatorLayout),
                                R.string.colorSet3, Snackbar.LENGTH_SHORT);
                        editor.putInt(getString(R.string.colorSetChangeKey), R.style.BlueMode);
                        break;
                    case 5:
                        mySnackbar = Snackbar.make(findViewById(R.id.myCoordinatorLayout),
                                R.string.colorSet4, Snackbar.LENGTH_SHORT);
                        editor.putInt(getString(R.string.colorSetChangeKey), R.style.RedMode);
                        break;
                    case 6:
                        mySnackbar = Snackbar.make(findViewById(R.id.myCoordinatorLayout),
                                R.string.colorSet5, Snackbar.LENGTH_SHORT);
                        editor.putInt(getString(R.string.colorSetChangeKey), R.style.PurpleMode);
                        break;
                    case 7:
                        mySnackbar = Snackbar.make(findViewById(R.id.myCoordinatorLayout),
                                R.string.colorSet6, Snackbar.LENGTH_SHORT);
                        editor.putInt(getString(R.string.colorSetChangeKey), R.style.YellowMode);
                        break;

                }
                if (position != 0) {
                    switch2Dark.setChecked(false);
                    editor.putBoolean(getString(R.string.darkModeEnabled), false);
                    mySnackbar.setAction(R.string.OK, new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                        }
                    });
                    editor.commit();
                    recreate();
                }
                staticSpinner.setSelection(0);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    public void changeToColorset1(View view) {
        Snackbar mySnackbar = Snackbar.make(findViewById(R.id.myCoordinatorLayout),
                R.string.colorSet1, Snackbar.LENGTH_SHORT);
        mySnackbar.setAction(R.string.OK, new View.OnClickListener() {
            @Override
            public void onClick(View v) {
            }
        });
        Context context = this;
        SharedPreferences sharedPref = context.getSharedPreferences(
                getString(R.string.preference_file_key), Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPref.edit();
        editor.putInt(getString(R.string.colorSetChangeKey), R.style.PinkMode);
        editor.putBoolean(getString(R.string.darkModeEnabled), false);
        switch2Dark.setChecked(false);
        editor.commit();
        recreate();
    }

    public void changeToColorset2(View view) {
        Snackbar mySnackbar = Snackbar.make(findViewById(R.id.myCoordinatorLayout),
                R.string.colorSet2, Snackbar.LENGTH_SHORT);
        mySnackbar.setAction(R.string.OK, new View.OnClickListener() {
            @Override
            public void onClick(View v) {
            }
        });
        Context context = this;
        SharedPreferences sharedPref = context.getSharedPreferences(
                getString(R.string.preference_file_key), Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPref.edit();
        editor.putInt(getString(R.string.colorSetChangeKey), R.style.GreenMode);
        editor.putBoolean(getString(R.string.darkModeEnabled), false);
        switch2Dark.setChecked(false);
        editor.commit();
        recreate();
        mySnackbar.show();
    }

    public void changeToColorset3(View view) {
        Snackbar mySnackbar = Snackbar.make(findViewById(R.id.myCoordinatorLayout),
                R.string.colorSet3, Snackbar.LENGTH_SHORT);
        mySnackbar.setAction(R.string.OK, new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        });
        mySnackbar.show();

        Context context = this;
        SharedPreferences sharedPref = context.getSharedPreferences(
                getString(R.string.preference_file_key), Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPref.edit();
        editor.putInt(getString(R.string.colorSetChangeKey), R.style.BlueMode); // change to wished theme
        editor.putBoolean(getString(R.string.darkModeEnabled), false);
        switch2Dark.setChecked(false);
        editor.commit();
        recreate();
    }

    public void changeToColorset4(View view) {
        Snackbar mySnackbar = Snackbar.make(findViewById(R.id.myCoordinatorLayout),
                R.string.colorSet4, Snackbar.LENGTH_SHORT);
        mySnackbar.setAction(R.string.OK, new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        });
        mySnackbar.show();

        Context context = this;
        SharedPreferences sharedPref = context.getSharedPreferences(
                getString(R.string.preference_file_key), Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPref.edit();
        editor.putInt(getString(R.string.colorSetChangeKey), R.style.RedMode); // change to wished theme
        editor.putBoolean(getString(R.string.darkModeEnabled), false);
        switch2Dark.setChecked(false);
        editor.commit();
        recreate();
    }

    public void changeToColorset5(View view) {
        Snackbar mySnackbar = Snackbar.make(findViewById(R.id.myCoordinatorLayout),
                R.string.colorSet5, Snackbar.LENGTH_SHORT);
        mySnackbar.setAction(R.string.OK, new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        });
        mySnackbar.show();

        Context context = this;
        SharedPreferences sharedPref = context.getSharedPreferences(
                getString(R.string.preference_file_key), Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPref.edit();
        editor.putInt(getString(R.string.colorSetChangeKey), R.style.PurpleMode); // change to wished theme
        switch2Dark.setChecked(false);
        editor.putBoolean(getString(R.string.darkModeEnabled), false);
        editor.commit();
        recreate();
    }

    public void changeToColorset6(View view) {
        Snackbar mySnackbar = Snackbar.make(findViewById(R.id.myCoordinatorLayout),
                R.string.colorSet6, Snackbar.LENGTH_SHORT);
        mySnackbar.setAction(R.string.OK, new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        });
        mySnackbar.show();

        Context context = this;
        SharedPreferences sharedPref = context.getSharedPreferences(
                getString(R.string.preference_file_key), Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPref.edit();
        editor.putInt(getString(R.string.colorSetChangeKey), R.style.YellowMode); // change to wished theme
        editor.putBoolean(getString(R.string.darkModeEnabled), false);
        switch2Dark.setChecked(false);
        editor.commit();
        recreate();
    }

    public void goToDefault(View view) {
        Snackbar mySnackbar = Snackbar.make(findViewById(R.id.myCoordinatorLayout),
                R.string.colorSet1, Snackbar.LENGTH_SHORT);
        mySnackbar.setAction(R.string.OK, new View.OnClickListener() {
            @Override
            public void onClick(View v) {
            }
        });
        Context context = this;
        SharedPreferences sharedPref = context.getSharedPreferences(
                getString(R.string.preference_file_key), Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPref.edit();
        editor.putInt(getString(R.string.colorSetChangeKey), R.style.AppTheme);
        editor.putBoolean(getString(R.string.darkModeEnabled), false);
        switch2Dark.setChecked(false);
        editor.commit();
        recreate();
    }
}
