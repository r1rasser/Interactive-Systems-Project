package android.hkrs.orchestra_app;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.design.widget.NavigationView;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;

import com.github.nkzawa.socketio.client.IO;
import com.github.nkzawa.socketio.client.Socket;

import java.net.URISyntaxException;
import java.util.Locale;


public class MainActivity extends AppCompatActivity
        implements Appointment.OnFragmentInteractionListener, NewsItem.OnFragmentInteractionListener, NavigationView.OnNavigationItemSelectedListener, ProfileFragment.OnFragmentInteractionListener, SettingsFragment.OnFragmentInteractionListener, MyAppointmentsFragmnet.OnFragmentInteractionListener, NewsFragment.OnFragmentInteractionListener {
    private static final char[] hexChars = ("0123456789abcdef").toCharArray();
    private static final String lang = Locale.getDefault().getLanguage();
    private Socket mSocket;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        Fragment fragment = null;
        Class fragmentClass = null;
        fragmentClass = ProfileFragment.class;
        try {
            mSocket = IO.socket("http://" + this.getString(R.string.server_host) + ":3000");
            mSocket.connect();
        } catch (URISyntaxException e) {
        }
        try {
            fragment = (Fragment) fragmentClass.newInstance();
        } catch (Exception e) {
            e.printStackTrace();
        }
        FragmentManager fragmentManager = getSupportFragmentManager();
        fragmentManager.beginTransaction().replace(R.id.flContent, fragment).commit();

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();

        NavigationView navigationView = (NavigationView) findViewById(R.id.nav_view);
        Menu menu = navigationView.getMenu();
        if (lang.equals("de")) {
            menu.getItem(0).setTitle(getString(R.string.nav_profile));
            menu.getItem(1).setTitle(getString(R.string.nav_appointments));
            menu.getItem(2).setTitle(getString(R.string.nav_news));
            menu.getItem(3).setTitle(getString(R.string.nav_settings));
        } else {
            menu.getItem(0).setTitle(getString(R.string.nav_profile_en));
            menu.getItem(1).setTitle(getString(R.string.nav_appointments_en));
            menu.getItem(2).setTitle(getString(R.string.nav_news_en));
            menu.getItem(3).setTitle(getString(R.string.nav_settings_en));
        }
        navigationView.setNavigationItemSelectedListener(this);
    }

    @Override
    public void onBackPressed() {
        finishAffinity();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        if (lang.equals("de")) {
            menu.getItem(0).setTitle(getString(R.string.action_settings));
            menu.getItem(1).setTitle(getString(R.string.action_edit_profile));
        } else {
            menu.getItem(0).setTitle(getString(R.string.action_settings_en));
            menu.getItem(1).setTitle(getString(R.string.action_edit_profile_en));
        }
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        Fragment fragment = null;
        Class fragmentClass = null;
        if (id == R.id.action_settings) {
            fragmentClass = SettingsFragment.class;
            try {
                fragment = (Fragment) fragmentClass.newInstance();
            } catch (Exception e) {
                e.printStackTrace();
            }
            if (fragment instanceof SettingsFragment) {
                ((SettingsFragment) fragment).setmSocket(mSocket);
            }
            FragmentManager fragmentManager = getSupportFragmentManager();
            fragmentManager.beginTransaction().replace(R.id.flContent, fragment).commit();
            return true;
        }
        if (id == R.id.action_edit_profile) {
            try {
                fragment = ProfileFragment.newInstance(true);
            } catch (Exception e) {
                e.printStackTrace();
            }
            FragmentManager fragmentManager = getSupportFragmentManager();
            fragmentManager.beginTransaction().replace(R.id.flContent, fragment).commit();
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.
        int id = item.getItemId();
        Fragment fragment = null;
        Class fragmentClass = null;
        if (id == R.id.nav_profile) {
            fragmentClass = ProfileFragment.class;
        } else if (id == R.id.nav_appointments) {
            fragmentClass = MyAppointmentsFragmnet.class;
        } else if (id == R.id.nav_news) {
            fragmentClass = NewsFragment.class;
        } else if (id == R.id.nav_settings) {
            fragmentClass = SettingsFragment.class;
        }
        try {
            fragment = (Fragment) fragmentClass.newInstance();
            if (fragment instanceof MyAppointmentsFragmnet) {
                ((MyAppointmentsFragmnet) fragment).setmSocket(mSocket);
            } else if (fragment instanceof NewsFragment) {
                ((NewsFragment) fragment).setmSocket(mSocket);
            } else if (fragment instanceof SettingsFragment) {
                ((SettingsFragment) fragment).setmSocket(mSocket);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        FragmentManager fragmentManager = getSupportFragmentManager();
        fragmentManager.beginTransaction().replace(R.id.flContent, fragment).commit();

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }

    @Override
    public void onFragmentInteraction(Uri uri) {

    }
}
