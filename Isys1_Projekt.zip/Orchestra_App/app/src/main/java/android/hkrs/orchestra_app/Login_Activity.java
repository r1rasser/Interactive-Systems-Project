package android.hkrs.orchestra_app;

import android.app.ActivityManager;
import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.SystemClock;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.util.Patterns;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.TimeoutError;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Locale;

public class Login_Activity extends AppCompatActivity {
    private static final char[] hexChars = ("0123456789abcdef").toCharArray();
    private static final String lang = Locale.getDefault().getLanguage();
    private static String loginMessageEmail;
    private static String loginMessageUsername;
    private static String loginMessageConnection;
    private Intent intent;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login_);
        if (lang.equals("de")) {
            loginMessageEmail = "Email oder Passwort falsch!";
            loginMessageUsername = "Username oder Passwort falsch!";
            loginMessageConnection = "Verbindung fehlgeschlagen!";
            ((TextView) findViewById(R.id.txtEmail)).setHint(R.string.em_or_un);
            ((TextView) findViewById(R.id.txtPassword)).setHint(R.string.pw);
        } else {
            loginMessageEmail = "Email or password incorrect!";
            loginMessageUsername = "Username or password incorrect!";
            loginMessageConnection = "Connection error!";
            ((TextView) findViewById(R.id.txtEmail)).setHint(R.string.em_or_un_en);
            ((TextView) findViewById(R.id.txtPassword)).setHint(R.string.pw_en);
        }

        intent = new Intent(this, MainActivity.class);
        Context c = getApplication();
        SharedPreferences sharedPref = c.getSharedPreferences(getString(R.string.shared_pref_file_key), Context.MODE_PRIVATE);
        String defaultValueToken = getResources().getString(R.string.orchestra_app_token_default);
        final String token = sharedPref.getString(getString(R.string.orchestra_app_token), defaultValueToken);
        String defaultValueEmail = getResources().getString(R.string.orchestra_app_credentials_default);
        final String email = sharedPref.getString(getString(R.string.orchestra_app_credentials_e), defaultValueEmail);
        if (!token.equals("null") && !email.equals("null")) {
            startActivity(intent);
        }
    }

    @Override
    public void onBackPressed() {
        finishAffinity();
    }

    // Used to load the 'native-lib' library on application startup.
    static {
        System.loadLibrary("native-lib");
    }

    public void login(View view) throws JSONException, NoSuchAlgorithmException {
        TextView tEU = (TextView) findViewById(R.id.txtEmail);
        TextView tPW = (TextView) findViewById(R.id.txtPassword);
        final ProgressBar loginProgr = (ProgressBar) findViewById(R.id.loginProgress);
        final TextView tLogin = (TextView) findViewById(R.id.loginMsg);
        if (tEU.getText().length() == 0 && tPW.getText().length() == 0) {
            tLogin.setText("Logindaten erforderlich!");
            Log.d("LOGIN_DATA", "msg: " + tLogin.getText());
        } else if (tEU.getText().length() == 0) {
            tLogin.setText("Email/Username erforderlich!");
            Log.d("LOGIN_DATA", "msg: " + tLogin.getText());
        } else if (tPW.getText().length() == 0) {
            tLogin.setText("Passwort erforderlich!");
            Log.d("LOGIN_DATA", "msg: " + tLogin.getText());
        } else {
            tLogin.setText("");
            loginProgr.setVisibility(View.VISIBLE);
//            String url = "http://192.168.0.241:3000/member/login";
            String url = "http://"+getString(R.string.server_host)+":3000/member/login";
            RequestQueue requestQueue = Volley.newRequestQueue(this);
            final boolean isEmail = Patterns.EMAIL_ADDRESS.matcher(tEU.getText()).matches();
            JSONObject body = getBody(tEU, tPW, isEmail);
            JsonObjectRequest loginRequest = new JsonObjectRequest(
                    Request.Method.POST, url, body,
                    new Response.Listener<JSONObject>() {
                        @Override
                        public void onResponse(JSONObject response) {
                            String token = null;
                            String email = null;
                            String username = null;
                            try {
                                token = response.getString("token").replaceAll("\"", "");
                                email = response.getString("email");
                                username = response.getString("username");
                            } catch (JSONException e) {
                                e.printStackTrace();
                            }
                            SharedPreferences sharedPref = getApplication().getSharedPreferences(getString(R.string.shared_pref_file_key), Context.MODE_PRIVATE);
                            SharedPreferences.Editor editor = sharedPref.edit();
                            editor.putString(getString(R.string.orchestra_app_token), token);
                            editor.putString(getString(R.string.orchestra_app_credentials_e), email);
                            editor.putString(getString(R.string.orchestra_app_credentials_u), username);
                            editor.commit();
                            loginProgr.setVisibility(View.INVISIBLE);
                            startActivity(intent);
                        }
                    },
                    new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {
                            loginProgr.setVisibility(View.INVISIBLE);
                            if (error instanceof TimeoutError) {
                                tLogin.setText(loginMessageConnection);
                                // TODO: Remove startActivity(...)
                                startActivity(intent);
                            } else {
                                if (isEmail) {
                                    tLogin.setText(loginMessageEmail);
                                } else {
                                    tLogin.setText(loginMessageUsername);
                                }
                            }
                        }
                    });
            requestQueue.add(loginRequest);
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
    }

    private JSONObject getBody(TextView tEU, TextView tPW, boolean isEmail) throws JSONException, NoSuchAlgorithmException {
        JSONObject credentials = new JSONObject();
        JSONObject body = new JSONObject();
        if (isEmail) {
            credentials.put("email", tEU.getText());
            credentials.put("username", "");
        } else {
            credentials.put("email", "");
            credentials.put("username", tEU.getText());
        }
        String pwShaStr = getSHAString(MessageDigest.getInstance("SHA-512").digest(tPW.getText().toString().getBytes()));
        credentials.put("password", pwShaStr);
        body.put("credentials", credentials);
        return body;
    }

    private String getSHAString(byte[] pwSHA) {
        char[] pwChars = new char[pwSHA.length * 2];
        for (int i = 0; i < pwSHA.length; i++) {
            int v = pwSHA[i] & 0xff;
            pwChars[2 * i] = hexChars[v >>> 4];
            pwChars[2 * i + 1] = hexChars[v & 0x0f];
        }
        return new String(pwChars);
    }
}