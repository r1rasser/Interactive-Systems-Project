package android.hkrs.orchestra_app;

import android.content.Context;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.ms.square.android.expandabletextview.ExpandableTextView;

import java.util.Arrays;
import java.util.StringTokenizer;

import butterknife.ButterKnife;

/**
 * A simple {@link Fragment} subclass.
 * Activities that contain this fragment must implement the
 * {@link Appointment.OnFragmentInteractionListener} interface
 * to handle interaction events.
 * Use the {@link Appointment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class Appointment extends Fragment {
    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String TITLE_PARAM = "title";
    private static final String CONTENT_PARAM = "content";

    // TODO: Rename and change types of parameters
    private String title;
    private String content;

    private OnFragmentInteractionListener mListener;

    private LinearLayout linearLayout;

    public Appointment() {
        // Required empty public constructor
    }

    public String getTitle() {
        return title;
    }

    public String getContent() {
        return content;
    }

    public int[] getStart(){
        StringTokenizer tokenizer = new StringTokenizer(content,"\n");
        tokenizer.nextToken();
        String startString = tokenizer.nextToken();
        int[] start = new int[5];
        String[] startSplit = startString.split("-|T|:|\\.");
        start[0] = Integer.parseInt(startSplit[0]);
        start[1] = Integer.parseInt(startSplit[1]) - 1;
        start[2] = Integer.parseInt(startSplit[2]);
        start[3] = Integer.parseInt(startSplit[3]) + 1;
        start[4] = Integer.parseInt(startSplit[4]);
        Log.d("TIME_WE_GOT", Arrays.toString(start));
        return start;
    }
    public int[] getEnd(){
        StringTokenizer tokenizer = new StringTokenizer(content,"\n");
        tokenizer.nextToken();
        tokenizer.nextToken();
        String startString = tokenizer.nextToken();
        int[] end = new int[5];
        String[] startSplit = startString.split("-|T|:|\\.");
        end[0] = Integer.parseInt(startSplit[0]);
        end[1] = Integer.parseInt(startSplit[1]) - 1;
        end[2] = Integer.parseInt(startSplit[2]);
        end[3] = Integer.parseInt(startSplit[3]) + 1;
        end[4] = Integer.parseInt(startSplit[4]);
        Log.d("TIME_WE_GOT", Arrays.toString(end));
        return end;
    }
    public String getProgram(){

        return "Test text :o";
    }
    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param title Parameter 1.
     * @param content Parameter 2.
     * @return A new instance of fragment Appointment.
     */
    // TODO: Rename and change types and number of parameters
    public static Appointment newInstance(String title, String content) {
        Appointment fragment = new Appointment();
        Bundle args = new Bundle();
        args.putString(TITLE_PARAM, title);
        args.putString(CONTENT_PARAM, content);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            title = getArguments().getString(TITLE_PARAM);
            content = getArguments().getString(CONTENT_PARAM);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View inflated = inflater.inflate(R.layout.appointment_item, container, false);
        linearLayout = inflated.findViewById(R.id.appointment_container);
        ExpandableTextView expandableTextView = (ExpandableTextView) linearLayout.findViewById(R.id.expand_text_view);
        ((TextView) expandableTextView.findViewById(R.id.title)).setText(title);
        expandableTextView.setText(content);
        ButterKnife.bind(this, inflated);
        return inflated;
    }

    // TODO: Rename method, update argument and hook method into UI event
    public void onButtonPressed(Uri uri) {
        if (mListener != null) {
            mListener.onFragmentInteraction(uri);
        }
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof OnFragmentInteractionListener) {
            mListener = (OnFragmentInteractionListener) context;
        } else {
            throw new RuntimeException(context.toString()
                    + " must implement OnFragmentInteractionListener");
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }

    /**
     * This interface must be implemented by activities that contain this
     * fragment to allow an interaction in this fragment to be communicated
     * to the activity and potentially other fragments contained in that
     * activity.
     * <p>
     * See the Android Training lesson <a href=
     * "http://developer.android.com/training/basics/fragments/communicating.html"
     * >Communicating with Other Fragments</a> for more information.
     */
    public interface OnFragmentInteractionListener {
        // TODO: Update argument type and name
        void onFragmentInteraction(Uri uri);
    }
}
