package android.hkrs.orchestra_app;

import android.app.Activity;
import android.app.DatePickerDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.support.design.widget.Snackbar;
import android.support.v4.app.DialogFragment;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v7.app.AlertDialog;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.ImageView;
import android.widget.TextView;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

import butterknife.ButterKnife;


/**
 * A simple {@link Fragment} subclass.
 * Activities that contain this fragment must implement the
 * {@link ProfileFragment.OnFragmentInteractionListener} interface
 * to handle interaction events.
 * Use the {@link ProfileFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class ProfileFragment extends Fragment {
    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";
    private static final int GET_FROM_GALLERY = 3;
    private static String usernameRef = "";
    private static final String lang = Locale.getDefault().getLanguage();
    private String[] dataBeforeEdit;
    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;

    private OnFragmentInteractionListener mListener;

    public ProfileFragment() {
        // Required empty public constructor
    }


    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param editEnabled Parameter 1.
     * @return A new instance of fragment ProfileFragment.
     */
    // TODO: Rename and change types and number of parameters
    public static ProfileFragment newInstance(boolean editEnabled) {
        ProfileFragment fragment = new ProfileFragment();
        Bundle args = new Bundle();
        args.putBoolean(ARG_PARAM1, editEnabled);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(final Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getActivity().getWindow().setSoftInputMode(
                WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);
        Context c = getActivity();
        SharedPreferences sharedPref = c.getSharedPreferences(getString(R.string.shared_pref_file_key), Context.MODE_PRIVATE);

        String defaultValueToken = getResources().getString(R.string.orchestra_app_token_default);
        final String token = sharedPref.getString(getString(R.string.orchestra_app_token), defaultValueToken);

        String defaultValueEmail = getResources().getString(R.string.orchestra_app_credentials_default);
        final String email = sharedPref.getString(getString(R.string.orchestra_app_credentials_e), defaultValueEmail);
        String url = "http://"+getString(R.string.server_host)+":3000/member/userData/" + email;
        final RequestQueue requestQueue = Volley.newRequestQueue(getActivity());
        JsonObjectRequest loginRequest = new JsonObjectRequest(
                Request.Method.GET, url, null,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        if (lang.equals("de")) {
                            ((Button) getActivity().findViewById(R.id.save)).setText(R.string.save);
                            ((Button) getActivity().findViewById(R.id.cancel)).setText(R.string.cancel);
                            ((TextView) getActivity().findViewById(R.id.mebernumber)).setHint(R.string.mn);
                            ((TextView) getActivity().findViewById(R.id.fn)).setHint(R.string.fn);
                            ((TextView) getActivity().findViewById(R.id.ln)).setHint(R.string.ln);
                            ((TextView) getActivity().findViewById(R.id.dob)).setHint(R.string.dob);
                            ((TextView) getActivity().findViewById(R.id.email)).setHint(R.string.em);
                            ((TextView) getActivity().findViewById(R.id.username)).setHint(R.string.un);
                            ((TextView) getActivity().findViewById(R.id.phone)).setHint(R.string.ph);
                            ((TextView) getActivity().findViewById(R.id.mobile)).setHint(R.string.mo);
                            ((TextView) getActivity().findViewById(R.id.street_num)).setHint(R.string.sn);
                            ((TextView) getActivity().findViewById(R.id.zip_city)).setHint(R.string.zc);
                        } else {
                            ((Button) getActivity().findViewById(R.id.save)).setText(R.string.save_en);
                            ((Button) getActivity().findViewById(R.id.cancel)).setText(R.string.cancel_en);
                            ((TextView) getActivity().findViewById(R.id.mebernumber)).setHint(R.string.mn_en);
                            ((TextView) getActivity().findViewById(R.id.fn)).setHint(R.string.fn_en);
                            ((TextView) getActivity().findViewById(R.id.ln)).setHint(R.string.ln_en);
                            ((TextView) getActivity().findViewById(R.id.dob)).setHint(R.string.dob_en);
                            ((TextView) getActivity().findViewById(R.id.email)).setHint(R.string.em_en);
                            ((TextView) getActivity().findViewById(R.id.username)).setHint(R.string.un_en);
                            ((TextView) getActivity().findViewById(R.id.phone)).setHint(R.string.ph_en);
                            ((TextView) getActivity().findViewById(R.id.mobile)).setHint(R.string.mo_en);
                            ((TextView) getActivity().findViewById(R.id.street_num)).setHint(R.string.sn_en);
                            ((TextView) getActivity().findViewById(R.id.zip_city)).setHint(R.string.zc_en);
                        }
                        getActivity().findViewById(R.id.edit_img).setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                uploadImage();
                            }
                        });
                        boolean enabled = false;
                        Bundle args = getArguments();
                        if (args != null) {
                            enabled = args.getBoolean(ARG_PARAM1, false);
                        }
                        try {
                            usernameRef = response.getJSONObject("member").getString("username");
                        } catch (JSONException e) {
                        }
                        setFields(response, enabled);
                        dataBeforeEdit = new String[]{
                                ((TextView) getActivity().findViewById(R.id.email)).getText().toString(),
                                ((TextView) getActivity().findViewById(R.id.username)).getText().toString(),
                                ((TextView) getActivity().findViewById(R.id.phone)).getText().toString(),
                                ((TextView) getActivity().findViewById(R.id.mobile)).getText().toString()
                        };
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Log.d("MEMBER_DATA_ERR", error.toString());
                    }
                }) {
            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {
                Map<String, String> headers = new HashMap<>();
                headers.put("Content-Type", "application/json");
                headers.put("Authorization", token);
                return headers;
            }
        };
        requestQueue.add(loginRequest);
    }

    public void uploadImage() {
        startActivityForResult(new Intent(Intent.ACTION_PICK, android.provider.MediaStore.Images.Media.INTERNAL_CONTENT_URI), GET_FROM_GALLERY);
    }

    private void setFields(JSONObject response, boolean enabled) {
        TextView memnum = (TextView) getActivity().findViewById(R.id.mebernumber);
        TextView fn = (TextView) getActivity().findViewById(R.id.fn);
        TextView ln = (TextView) getActivity().findViewById(R.id.ln);
        TextView dob = (TextView) getActivity().findViewById(R.id.dob);
        TextView em = (TextView) getActivity().findViewById(R.id.email);
        TextView usrname = (TextView) getActivity().findViewById(R.id.username);
        TextView mob = (TextView) getActivity().findViewById(R.id.mobile);
        TextView ph = (TextView) getActivity().findViewById(R.id.phone);
        TextView ins = (TextView) getActivity().findViewById(R.id.instrument);
        TextView strtNum = (TextView) getActivity().findViewById(R.id.street_num);
        TextView zipCity = (TextView) getActivity().findViewById(R.id.zip_city);
        Button cancel = (Button) getActivity().findViewById(R.id.cancel);
        Button save = (Button) getActivity().findViewById(R.id.save);
        if (enabled) {
            cancel.setVisibility(View.VISIBLE);
            save.setVisibility(View.VISIBLE);
            cancel.setOnClickListener(new CancelAction());
            save.setOnClickListener(new SaveAction());
            dob.setOnClickListener(new OpenDatePickerAction());
        }
        memnum.setEnabled(false);
        fn.setEnabled(false);
        ln.setEnabled(false);
        dob.setEnabled(false);
        em.setEnabled(enabled);
        usrname.setEnabled(enabled);
        mob.setEnabled(enabled);
        ph.setEnabled(enabled);
        ins.setEnabled(false);
        strtNum.setEnabled(false);
        zipCity.setEnabled(false);

        if (response != null) {
            JSONObject data;
            String membernumber = null;
            String firstname = null;
            String lastname = null;
            String dateOfBirth = null;
            String email = null;
            String username = null;
            String instrument = null;
            String phone = null;
            String mobile = null;
            String strt_num = null;
            String zip_city = null;
            try {
                data = response.getJSONObject("data");
                JSONObject member = data.getJSONObject("member");
                JSONObject address = data.getJSONObject("address");
                membernumber = member.getString("membernumber");
                firstname = member.getString("firstname");
                lastname = member.getString("lastname");
                dateOfBirth = member.getString("dob");
                email = member.getString("email");
                username = member.getString("username");
                phone = member.getString("phone");
                mobile = member.getString("mobile");
                instrument = member.getString("instrument");
                strt_num = address.getString("street") + "/" + address.getString("number");
                zip_city = address.getString("ZIP") + "/" + address.getString("city");
            } catch (JSONException e) {
                e.printStackTrace();
            }
            String dob_new = "";
            String day = (Integer.parseInt(dateOfBirth.substring(8, 10))) + "";
            dob_new += day + "." + dateOfBirth.substring(5, 7) + "." + dateOfBirth.substring(0, 4);

            memnum.setText(membernumber);
            fn.setText(firstname);
            ln.setText(lastname);
            dob.setText(dob_new);
            em.setText(email);
            usrname.setText(username);
            mob.setText(mobile);
            ph.setText(phone);
            ins.setText(instrument);
            strtNum.setText(strt_num);
            zipCity.setText(zip_city);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View v = inflater.inflate(R.layout.fragment_profilefragment, container, false);
        ButterKnife.bind(this, v);
        return v;
    }

    // TODO: Rename method, update argument and hook method into UI event
    public void onButtonPressed(Uri uri) {
        if (mListener != null) {
            mListener.onFragmentInteraction(uri);
        }
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof OnFragmentInteractionListener) {
            mListener = (OnFragmentInteractionListener) context;
        } else {
            throw new RuntimeException(context.toString()
                    + " must implement OnFragmentInteractionListener");
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }

    public interface OnFragmentInteractionListener {
        // TODO: Update argument type and name
        void onFragmentInteraction(Uri uri);
    }

    public class CancelAction implements View.OnClickListener {
        @Override
        public void onClick(View v) {
            try {
                Button cancel = (Button) getActivity().findViewById(R.id.cancel);
                Button save = (Button) getActivity().findViewById(R.id.save);
                TextView dob = (TextView) getActivity().findViewById(R.id.dob);
                cancel.setVisibility(View.INVISIBLE);
                save.setVisibility(View.INVISIBLE);
                cancel.setOnClickListener(null);
                save.setOnClickListener(null);
                dob.setOnClickListener(null);
                // TODO: RESET FIELDS
                resetFields(false);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    public class SaveAction implements View.OnClickListener {
        @Override
        public void onClick(View v) {
            try {
                DialogFragment newFragment = new ConfirmSaveDialog();
                newFragment.setTargetFragment(ProfileFragment.this, 1);
                newFragment.setArguments(getData());
                newFragment.show(getActivity().getSupportFragmentManager(), "Confirm");
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    private Bundle getData() {
        Bundle data = new Bundle();
        data.putStringArray("Update_Data", new String[]{
                ((TextView) getActivity().findViewById(R.id.email)).getText().toString(),
                ((TextView) getActivity().findViewById(R.id.username)).getText().toString(),
                ((TextView) getActivity().findViewById(R.id.phone)).getText().toString(),
                ((TextView) getActivity().findViewById(R.id.mobile)).getText().toString()
        });
        return data;
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (resultCode == Activity.RESULT_OK && requestCode != GET_FROM_GALLERY) {
            Button cancel = (Button) getActivity().findViewById(R.id.cancel);
            Button save = (Button) getActivity().findViewById(R.id.save);
            TextView dob = (TextView) getActivity().findViewById(R.id.dob);
            cancel.setVisibility(View.INVISIBLE);
            save.setVisibility(View.INVISIBLE);
            cancel.setOnClickListener(null);
            save.setOnClickListener(null);
            dob.setOnClickListener(null);
            Log.d("DIALOG_OK", "reqCode: " + requestCode + ", resCode: " + resultCode + ", Password: " + data.getStringExtra("confirm_password"));
            setFields(null, false);
            String snackbarMessage;
            if (lang.equals("de")) {
                snackbarMessage = getString(R.string.saved_message);
            } else {
                snackbarMessage = getString(R.string.saved_message_en);
            }
            Snackbar saveSnackbar = Snackbar.make(getActivity().findViewById(R.id.myCoordinatorLayout), snackbarMessage, Snackbar.LENGTH_LONG);
            saveSnackbar.setAction(R.string.OK, new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                }
            });
            saveSnackbar.show();
        } else if (requestCode == GET_FROM_GALLERY && resultCode == Activity.RESULT_OK) {
            Log.d("IMG_UPLOAD","Image successfully uploaded ^^");
            Uri selectedImage = data.getData();
            Bitmap bitmap = null;
            try {
                bitmap = android.provider.MediaStore.Images.Media.getBitmap(getActivity().getContentResolver(), selectedImage);
                ((ImageView) getActivity().findViewById(R.id.profile_img)).setImageBitmap(bitmap);
            } catch (FileNotFoundException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            } catch (IOException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
        } else {
            Log.d("DIALOG_CANCEL", "reqCode: " + requestCode + ", resCode: " + resultCode + ", Password: " + data.getStringExtra("confirm_password"));
            setFields(null, false);
            // TODO: RESET FIELDS
            setFields(null, true);
        }
    }

    public static Intent newIntent(String pw) {
        Intent i = new Intent();
        i.putExtra("confirm_password", pw);
        return i;
    }

    private void resetFields(boolean enabled) {
        TextView dob = (TextView) getActivity().findViewById(R.id.dob);
        TextView em = (TextView) getActivity().findViewById(R.id.email);
        TextView usrname = (TextView) getActivity().findViewById(R.id.username);
        TextView mob = (TextView) getActivity().findViewById(R.id.mobile);
        TextView ph = (TextView) getActivity().findViewById(R.id.phone);
        Button cancel = (Button) getActivity().findViewById(R.id.cancel);
        Button save = (Button) getActivity().findViewById(R.id.save);
        if (enabled) {
            cancel.setVisibility(View.VISIBLE);
            save.setVisibility(View.VISIBLE);
            cancel.setOnClickListener(new CancelAction());
            save.setOnClickListener(new SaveAction());
            dob.setOnClickListener(new OpenDatePickerAction());
        } else {
            cancel.setVisibility(View.INVISIBLE);
            save.setVisibility(View.INVISIBLE);
            cancel.setOnClickListener(null);
            save.setOnClickListener(null);
            dob.setOnClickListener(null);
        }
        em.setText(dataBeforeEdit[0]);
        usrname.setText(dataBeforeEdit[1]);
        mob.setText(dataBeforeEdit[3]);
        ph.setText(dataBeforeEdit[2]);
        em.setEnabled(enabled);
        usrname.setEnabled(enabled);
        ph.setEnabled(enabled);
        mob.setEnabled(enabled);
    }


    public static class DatePickerFragment extends DialogFragment
            implements DatePickerDialog.OnDateSetListener {

        @Override
        public Dialog onCreateDialog(Bundle savedInstanceState) {
            // Use the current date as the default date in the picker
            final Calendar c = Calendar.getInstance();
            int year = c.get(Calendar.YEAR);
            int month = c.get(Calendar.MONTH);
            int day = c.get(Calendar.DAY_OF_MONTH);

            // Create a new instance of DatePickerDialog and return it
            return new DatePickerDialog(getActivity(), this, year, month, day);
        }

        public void onDateSet(DatePicker view, int year, int month, int day) {
            TextView dob = (TextView) getActivity().findViewById(R.id.dob);
            dob.setText(day + "." + (month + 1) + "." + year);
        }
    }

    public class OpenDatePickerAction implements View.OnClickListener {
        @Override
        public void onClick(View v) {
            DialogFragment newFragment = new DatePickerFragment();
            newFragment.show(getActivity().getSupportFragmentManager(), "datePicker");
            TextView dob = (TextView) getActivity().findViewById(R.id.dob);
        }
    }
}
