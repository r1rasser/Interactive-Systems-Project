package android.hkrs.orchestra_app;

import android.content.Context;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.view.NestedScrollingChild;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.ms.square.android.expandabletextview.ExpandableTextView;

import org.json.JSONException;
import org.json.JSONObject;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.HashMap;
import java.util.Map;

import butterknife.ButterKnife;

/**
 * A simple {@link Fragment} subclass.
 * Activities that contain this fragment must implement the
 * {@link Appointment.OnFragmentInteractionListener} interface
 * to handle interaction events.
 * Use the {@link Appointment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class NewsItem extends Fragment {
    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String TITLE_PARAM = "title";
    private static final String CONTENT_PARAM = "content";
    private static final String READ_PARAM = "read";
    private static final String ID_PARAM = "id";

    // TODO: Rename and change types of parameters
    private String title;
    private String content;
    private boolean read;
    private int db_id;
    private String tag;

    private OnFragmentInteractionListener mListener;

    private LinearLayout linearLayout;

    public NewsItem() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param title   Parameter 1.
     * @param content Parameter 2.
     * @return A new instance of fragment Appointment.
     */
    // TODO: Rename and change types and number of parameters
    public static NewsItem newInstance(String title, String content, int id, boolean read) {
        NewsItem fragment = new NewsItem();
        Bundle args = new Bundle();
        args.putString(TITLE_PARAM, title);
        args.putString(CONTENT_PARAM, content);
        args.putBoolean(READ_PARAM, read);
        args.putInt(ID_PARAM, id);
        fragment.setArguments(args);
        return fragment;
    }

    public void setTag(String tag) {
        this.tag = tag;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            title = getArguments().getString(TITLE_PARAM);
            content = getArguments().getString(CONTENT_PARAM);
            read = getArguments().getBoolean(READ_PARAM);
            db_id = getArguments().getInt(ID_PARAM);
        }
    }

    public void setParent(Fragment parent) {
        onAttachToParentFragment(parent);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View inflated = null;
        if (read)
            inflated = inflater.inflate(R.layout.news_item, container, false);
        else
            inflated = inflater.inflate(R.layout.news_item_unread, container, false);
        linearLayout = inflated.findViewById(R.id.news_container);
        ExpandableTextView expandableTextView = (ExpandableTextView) linearLayout.findViewById(R.id.expand_text_view);
        if (!read)
            linearLayout.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    final Context c = getActivity();
                    SharedPreferences sharedPref = c.getSharedPreferences(getString(R.string.shared_pref_file_key), Context.MODE_PRIVATE);
                    String defaultValueToken = getResources().getString(R.string.orchestra_app_token_default);
                    final String token = sharedPref.getString(getString(R.string.orchestra_app_token), defaultValueToken);
                    String defaultValueEmail = getResources().getString(R.string.orchestra_app_credentials_default);
                    final String email = sharedPref.getString(getString(R.string.orchestra_app_credentials_e), defaultValueEmail);
                    JSONObject body = new JSONObject();
                    Log.d("DATA_", "Okay, we're here...");
                    try {
                        body.put("email", email);
                        body.put("id", db_id);
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                    Log.d("DATA_", body.toString());
                    String url = "http://"+getString(R.string.server_host)+":3000/news/markAsRead/";
                    final RequestQueue requestQueue = Volley.newRequestQueue(getActivity());
                    JsonObjectRequest saveReq = new JsonObjectRequest(
                            Request.Method.PATCH, url, body,
                            new Response.Listener<JSONObject>() {
                                @Override
                                public void onResponse(JSONObject response) {
                                    parent.markAsRead();
                                }
                            },
                            new Response.ErrorListener() {
                                @Override
                                public void onErrorResponse(VolleyError error) {
                                    Log.d("MARK_AS_READ_ERR", error.toString());
                                }
                            }) {
                        @Override
                        public Map<String, String> getHeaders() throws AuthFailureError {
                            Map<String, String> headers = new HashMap<>();
                            headers.put("Content-Type", "application/json");
                            headers.put("Authorization", token);
                            return headers;
                        }
                    };
                    requestQueue.add(saveReq);
                }
            });
        ((TextView) expandableTextView.findViewById(R.id.title)).setText(title);
        expandableTextView.setText(content);
        ButterKnife.bind(this, inflated);
        return inflated;
    }

    // TODO: Rename method, update argument and hook method into UI event
    public void onButtonPressed(Uri uri) {
        if (mListener != null) {
            mListener.onFragmentInteraction(uri);
        }
    }

    private MarkAsRead parent;

    public void onAttachToParentFragment(Fragment fragment) {
        try {
            parent = (MarkAsRead) fragment;

        } catch (ClassCastException e) {
            throw new ClassCastException(
                    fragment.toString() + " must implement OnPlayerSelectionSetListener");
        }
    }

    public interface MarkAsRead {
        void markAsRead();
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof OnFragmentInteractionListener) {
            mListener = (OnFragmentInteractionListener) context;
        } else {
            throw new RuntimeException(context.toString()
                    + " must implement OnFragmentInteractionListener");
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }

    /**
     * This interface must be implemented by activities that contain this
     * fragment to allow an interaction in this fragment to be communicated
     * to the activity and potentially other fragments contained in that
     * activity.
     * <p>
     * See the Android Training lesson <a href=
     * "http://developer.android.com/training/basics/fragments/communicating.html"
     * >Communicating with Other Fragments</a> for more information.
     */
    public interface OnFragmentInteractionListener {
        // TODO: Update argument type and name
        void onFragmentInteraction(Uri uri);
    }
}
