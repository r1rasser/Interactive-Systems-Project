package android.hkrs.orchestra_app;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.design.widget.Snackbar;
import android.support.v4.app.DialogFragment;
import android.support.v7.app.AlertDialog;
import android.util.JsonReader;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

import butterknife.ButterKnife;

public class ConfirmSaveDialog extends DialogFragment {

    private static final String lang = Locale.getDefault().getLanguage();
    private static final char[] hexChars = ("0123456789abcdef").toCharArray();
    private TextView pw1 = null;
    private TextView pwMessage = null;
    private ProgressBar updateProgress = null;
    private JSONObject body;
    private String[] data;
    private Bundle args;

    public interface NoticeDialogListener {
        public void onDialogPositiveClick(DialogFragment dialog);

        public void onDialogNegativeClick(DialogFragment dialog);
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);

    }

    private String getSHAString(byte[] pwSHA) {
        char[] pwChars = new char[pwSHA.length * 2];
        for (int i = 0; i < pwSHA.length; i++) {
            int v = pwSHA[i] & 0xff;
            pwChars[2 * i] = hexChars[v >>> 4];
            pwChars[2 * i + 1] = hexChars[v & 0x0f];
        }
        return new String(pwChars);
    }

    @Override
    public void setArguments(@Nullable Bundle args) {
        this.args = args;
    }

    @NonNull
    @Override
    public Dialog onCreateDialog(@Nullable Bundle savedInstanceState) {
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        builder.setTitle(lang.equals("de") ? (getString(R.string.confirm_save)) : (getString(R.string.confirm_save_en)));
        View viewInflated = LayoutInflater.from(getContext()).inflate(R.layout.confirm_save_dialog, (ViewGroup) getView(), false);
        ButterKnife.bind(this, viewInflated);
        pw1 = (TextView) viewInflated.findViewById(R.id.confirm_password);
        pwMessage = (TextView) viewInflated.findViewById(R.id.password_ok_message);
        updateProgress = (ProgressBar) viewInflated.findViewById(R.id.update_request_progressbar);
        pwMessage.setText("");
        updateProgress.setVisibility(View.INVISIBLE);
        data = args.getStringArray("Update_Data");
        body = getBody(data);
        Log.d("DATA_", Arrays.toString(data));
        builder.setView(viewInflated);
        builder.setPositiveButton(getString(R.string.OK), new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int id) {
            }
        })
                .setNegativeButton((lang.equals("de") ? (getString(R.string.cancel)) : (getString(R.string.cancel_en))), new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        Intent i = ProfileFragment.newIntent("");
                        getTargetFragment().onActivityResult(getTargetRequestCode(), Activity.RESULT_CANCELED, i);
                        dismiss();
                    }
                });
        return builder.create();
    }

    private JSONObject getBody(String[] data) {
        JSONObject b = new JSONObject();
        JSONObject credentials = new JSONObject();
        try {
            credentials.put("newEmail", data[0]);
            credentials.put("newUsername", data[1]);
            credentials.put("newPhone", data[2]);
            credentials.put("newMobile", data[3]);
            b.put("credentials", credentials);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return b;
    }

    @Override
    public void onResume() {
        super.onResume();
        final AlertDialog dialog = (AlertDialog) getDialog();
        if (dialog != null) {
            Button positive = (Button) dialog.getButton(Dialog.BUTTON_POSITIVE);
            positive.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (pw1 != null) {
                        final String password = pw1.getText().toString();
                        if (!password.equals("")) {
                            updateProgress.setVisibility(View.VISIBLE);
                            final Context c = getActivity();
                            SharedPreferences sharedPref = c.getSharedPreferences(getString(R.string.shared_pref_file_key), Context.MODE_PRIVATE);
                            String defaultValueToken = getResources().getString(R.string.orchestra_app_token_default);
                            final String token = sharedPref.getString(getString(R.string.orchestra_app_token), defaultValueToken);
                            String defaultValueEmail = getResources().getString(R.string.orchestra_app_credentials_default);
                            final String email = sharedPref.getString(getString(R.string.orchestra_app_credentials_e), defaultValueEmail);
                            String username = data[1];
                            String url = "http://"+getString(R.string.server_host)+":3000/member/checkUsername/" + username;
                            final RequestQueue requestQueue = Volley.newRequestQueue(getActivity());
                            JsonObjectRequest saveReq = new JsonObjectRequest(
                                    Request.Method.GET, url, null,
                                    new Response.Listener<JSONObject>() {
                                        @Override
                                        public void onResponse(JSONObject response) {
                                            String availability = "-1";
                                            try {
                                                availability = (response.getString("available"));
                                            } catch (JSONException e) {
                                                e.printStackTrace();
                                            }
                                            try {
                                                JSONObject cred = body.getJSONObject("credentials");
                                                cred.put("password", getSHAString(MessageDigest.getInstance("SHA-512").digest(password.getBytes())));
                                                cred.put("email", email);
                                                body.remove("credentials");
                                                body.put("credentials", cred);
                                            } catch (JSONException e) {
                                                e.printStackTrace();
                                            } catch (NoSuchAlgorithmException e) {
                                                e.printStackTrace();
                                            }
                                            Log.d("DATA_", body.toString());
                                            String url = "http://"+getString(R.string.server_host)+":3000/member/updateUsername";
                                            JsonObjectRequest updateUserDate = new JsonObjectRequest(
                                                    Request.Method.PATCH, url, body,
                                                    new Response.Listener<JSONObject>() {
                                                        @Override
                                                        public void onResponse(JSONObject response) {
                                                            String url = "http://"+getString(R.string.server_host)+":3000/member/updateUserdata";
                                                            JsonObjectRequest updateUsername = new JsonObjectRequest(
                                                                    Request.Method.PATCH, url, body,
                                                                    new Response.Listener<JSONObject>() {
                                                                        @Override
                                                                        public void onResponse(JSONObject response) {
                                                                            if (getTargetFragment() == null) {
                                                                                return;
                                                                            } else {
                                                                                Intent i = null;
                                                                                try {
                                                                                    i = ProfileFragment.newIntent(getSHAString(MessageDigest.getInstance("SHA-512").digest(password.getBytes())));
                                                                                } catch (NoSuchAlgorithmException e) {
                                                                                    e.printStackTrace();
                                                                                }
                                                                                getTargetFragment().onActivityResult(getTargetRequestCode(), Activity.RESULT_OK, i);
                                                                                updateProgress.setVisibility(View.INVISIBLE);
                                                                                dialog.dismiss();
                                                                            }
                                                                        }
                                                                    },
                                                                    new Response.ErrorListener() {
                                                                        @Override
                                                                        public void onErrorResponse(VolleyError error) {
                                                                            Log.d("USERDATA_UPDATE_FAILED", error.toString());
                                                                            updateProgress.setVisibility(View.INVISIBLE);
                                                                            pwMessage.setText("Userdatn updaten geht nit!");
                                                                        }
                                                                    }) {
                                                                @Override
                                                                public Map<String, String> getHeaders() throws AuthFailureError {
                                                                    Map<String, String> headers = new HashMap<>();
                                                                    headers.put("Content-Type", "application/json");
                                                                    headers.put("Authorization", token);
                                                                    return headers;
                                                                }
                                                            };
                                                            requestQueue.add(updateUsername);
                                                        }
                                                    },
                                                    new Response.ErrorListener() {
                                                        @Override
                                                        public void onErrorResponse(VolleyError error) {
                                                            Log.d("USERNAME_UPDATE_FAILED", error.toString());
                                                            updateProgress.setVisibility(View.INVISIBLE);
                                                            pwMessage.setText("Username updaten geht nit!");
                                                        }
                                                    }) {
                                                @Override
                                                public Map<String, String> getHeaders() throws AuthFailureError {
                                                    Map<String, String> headers = new HashMap<>();
                                                    headers.put("Content-Type", "application/json");
                                                    headers.put("Authorization", token);
                                                    return headers;
                                                }
                                            };
                                            requestQueue.add(updateUserDate);
                                            /*} else {
                                                updateProgress.setVisibility(View.INVISIBLE);
                                                Log.d("DATA_", "Okay, we're here...");
                                                pwMessage.setText("Username geht nit...!");
                                            }*/
                                        }
                                    },
                                    new Response.ErrorListener() {
                                        @Override
                                        public void onErrorResponse(VolleyError error) {
                                            Log.d("USERNAME_NOT_AVAILABLE", error.toString());
                                            updateProgress.setVisibility(View.INVISIBLE);
                                            pwMessage.setText("Username geht nit!");
                                        }
                                    }) {
                                @Override
                                public Map<String, String> getHeaders() throws AuthFailureError {
                                    Map<String, String> headers = new HashMap<>();
                                    headers.put("Content-Type", "application/json");
                                    headers.put("Authorization", token);
                                    return headers;
                                }
                            };
                            requestQueue.add(saveReq);
                        } else {
                            pwMessage.setText("You must enter your password to proceed!");
                        }
                    }
                }
            });
        }
    }
}
