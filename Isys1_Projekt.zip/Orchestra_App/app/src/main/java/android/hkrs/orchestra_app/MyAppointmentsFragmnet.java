package android.hkrs.orchestra_app;

import android.Manifest;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.CalendarContract;
import android.support.design.widget.Snackbar;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.github.nkzawa.emitter.Emitter;
import com.github.nkzawa.socketio.client.Socket;
import com.ms.square.android.expandabletextview.ExpandableTextView;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Locale;
import java.util.Map;

import butterknife.ButterKnife;


/**
 * A simple {@link Fragment} subclass.
 * Activities that contain this fragment must implement the
 * {@link MyAppointmentsFragmnet.OnFragmentInteractionListener} interface
 * to handle interaction events.
 * Use the {@link MyAppointmentsFragmnet#newInstance} factory method to
 * create an instance of this fragment.
 */
public class MyAppointmentsFragmnet extends Fragment implements Appointment.OnFragmentInteractionListener {
    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    private static final String lang = Locale.getDefault().getLanguage();

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;
    private LinearLayout linearLayout;

    private FragmentTransaction transaction;
    private OnFragmentInteractionListener mListener;
    private Socket mSocket;

    public void setmSocket(Socket mSocket) {
        this.mSocket = mSocket;
    }

    private ArrayList<Appointment> appointments;

    public MyAppointmentsFragmnet() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment MyAppointmentsFragmnet.
     */
    // TODO: Rename and change types and number of parameters
    public static MyAppointmentsFragmnet newInstance(String param1, String param2) {
        MyAppointmentsFragmnet fragment = new MyAppointmentsFragmnet();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
        mSocket.on("appointmentUpdate", new Emitter.Listener() {
            @Override
            public void call(Object... args) {
                makeRequest();
            }
        });
        appointments = new ArrayList<>();

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View inflated = inflater.inflate(R.layout.fragment_my_appointments_fragmnet, container, false);
        linearLayout = inflated.findViewById(R.id.appointments);
        ((Button) inflated.findViewById(R.id.synch)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    if (getActivity().checkSelfPermission(Manifest.permission.WRITE_CALENDAR) == PackageManager.PERMISSION_DENIED) {
                        requestPermissions(new String[]{Manifest.permission.WRITE_CALENDAR, Manifest.permission.READ_CALENDAR}, 1);
                    }
                    if (getActivity().checkSelfPermission(Manifest.permission.WRITE_CALENDAR) == PackageManager.PERMISSION_GRANTED) {
                        for (Appointment appointment : appointments) {
                            int[] start = appointment.getStart();
                            int[] end = appointment.getEnd();
                            long calID = 3;
                            long startMillis = 0;
                            long endMillis = 0;
                            Calendar beginTime = Calendar.getInstance();
                            beginTime.set(start[0], start[1], start[2], start[3], start[4]);
                            startMillis = beginTime.getTimeInMillis();
                            Calendar endTime = Calendar.getInstance();
                            endTime.set(end[0], end[1], end[2], end[3], end[4]);
                            endMillis = endTime.getTimeInMillis();
                            ContentResolver cr = getActivity().getContentResolver();
                            ContentValues values = new ContentValues();
                            values.put(CalendarContract.Events.DTSTART, startMillis);
                            values.put(CalendarContract.Events.DTEND, endMillis);
                            values.put(CalendarContract.Events.TITLE, appointment.getTitle());
                            values.put(CalendarContract.Events.DESCRIPTION, appointment.getProgram());
                            values.put(CalendarContract.Events.CALENDAR_ID, calID);
                            values.put(CalendarContract.Events.EVENT_TIMEZONE, "Austria");
                            Uri uri = cr.insert(CalendarContract.Events.CONTENT_URI, values);
                            long eventID = Long.parseLong(uri.getLastPathSegment());
                            // TODO store eventID into user_calender_appointments-table
                        }
                        String snackbarMessage;
                        if (lang.equals("de")) {
                            snackbarMessage = "Erfolgreich synchronisiert";
                        } else {
                            snackbarMessage = "Successfully synchronized";
                        }
                        Snackbar saveSnackbar = Snackbar.make(getActivity().findViewById(R.id.myCoordinatorLayout), snackbarMessage, Snackbar.LENGTH_LONG);
                        saveSnackbar.setAction(R.string.OK, new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                            }
                        });
                        saveSnackbar.show();
                    }
                }
            }
        });
        appointments = new ArrayList<>();
        makeRequest();
        ButterKnife.bind(this, inflated);
        return inflated;
    }

    private void makeRequest() {
        appointments = new ArrayList<>();
        Context c = getActivity();
        SharedPreferences sharedPref = c.getSharedPreferences(getString(R.string.shared_pref_file_key), Context.MODE_PRIVATE);

        String defaultValueToken = getResources().getString(R.string.orchestra_app_token_default);
        final String token = sharedPref.getString(getString(R.string.orchestra_app_token), defaultValueToken);

        String defaultValueEmail = getResources().getString(R.string.orchestra_app_credentials_default);
        final String email = sharedPref.getString(getString(R.string.orchestra_app_credentials_e), defaultValueEmail);
        String url = "http://" + getString(R.string.server_host) + ":3000/appointments/getUserAppointment/" + email;
        final RequestQueue requestQueue = Volley.newRequestQueue(getActivity());
        JsonObjectRequest loginRequest = new JsonObjectRequest(
                Request.Method.GET, url, null,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        try {
                            getAppointments(response);
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Log.d("APPOINTMENTS_ERR", error.toString());
                    }
                }) {
            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {
                Map<String, String> headers = new HashMap<>();
                headers.put("Content-Type", "application/json");
                headers.put("Authorization", token);
                return headers;
            }
        };
        requestQueue.add(loginRequest);
    }

    private void getAppointments(JSONObject response) throws JSONException {
        JSONObject appointmentsJSON = response.getJSONObject("appointments");
        Iterator<String> i = appointmentsJSON.keys();
        while (i.hasNext()) {
            String key = i.next();
            try {
                JSONObject appointmentObj = appointmentsJSON.getJSONObject(key);
                    /*
                        "type": result[i].type,
                        "start": result[i].start,
                        "end": result[i].end,
                        "comment":result[i].comment,
                        "program":{
                            "title":result[i].title,
                            "composer":result[i].composer
                        }
                     */
                String title = appointmentObj.getString("type");
                String start = appointmentObj.getString("start");
                String end = appointmentObj.getString("end");
                String comment = ""; //appointmentObj.getString("comment");
                JSONObject program = appointmentObj.getJSONObject("program");
                int j = 1;
                String programStr = "";
                Iterator<String> k = program.keys();
                while (k.hasNext()) {
                    String key_p = k.next();
                    JSONObject program_item = program.getJSONObject(key_p);
                    String name = program_item.getString("title");
                    String comp = program_item.getString("composer");
                    programStr += (k.hasNext()) ? (j + ". " + name + " (" + comp + ")\n") : (j + ". " + name + " (" + comp + ")");
                    j++;
                }
                String details = start + "\n" + start + "\n" + end + "\n" + comment + "\n" + programStr;
                appointments.add(Appointment.newInstance(title, details));
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
        int l = 0;
        FragmentManager manager = getActivity().getSupportFragmentManager();
        for (Appointment app : appointments) {
            transaction = manager.beginTransaction();
            transaction.add(R.id.appointments, app, "Appointment_" + l);
            transaction.commit();
            l++;
        }
    }

    // TODO: Rename method, update argument and hook method into UI event
    public void onButtonPressed(Uri uri) {
        if (mListener != null) {
            mListener.onFragmentInteraction(uri);
        }
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof OnFragmentInteractionListener) {
            mListener = (OnFragmentInteractionListener) context;
        } else {
            throw new RuntimeException(context.toString()
                    + " must implement OnFragmentInteractionListener");
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }

    @Override
    public void onFragmentInteraction(Uri uri) {

    }

    /**
     * This interface must be implemented by activities that contain this
     * fragment to allow an interaction in this fragment to be communicated
     * to the activity and potentially other fragments contained in that
     * activity.
     * <p>
     * See the Android Training lesson <a href=
     * "http://developer.android.com/training/basics/fragments/communicating.html"
     * >Communicating with Other Fragments</a> for more information.
     */
    public interface OnFragmentInteractionListener {
        // TODO: Update argument type and name
        void onFragmentInteraction(Uri uri);
    }
}
