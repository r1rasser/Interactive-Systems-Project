package android.hkrs.orchestra_app;

import android.content.Context;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.github.nkzawa.emitter.Emitter;
import com.github.nkzawa.socketio.client.Socket;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import butterknife.ButterKnife;


/**
 * A simple {@link Fragment} subclass.
 * Activities that contain this fragment must implement the
 * {@link NewsFragment.OnFragmentInteractionListener} interface
 * to handle interaction events.
 * Use the {@link NewsFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class NewsFragment extends Fragment implements NewsItem.MarkAsRead{
    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;
       private Socket mSocket;

    public void setmSocket(Socket mSocket) {
        this.mSocket = mSocket;
    }

    private ArrayList<NewsItem> news = new ArrayList<>();
    private LinearLayout linearLayout;
    private FragmentTransaction transaction;

    private OnFragmentInteractionListener mListener;

    public NewsFragment() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment NewsFragment.
     */
    // TODO: Rename and change types and number of parameters
    public static NewsFragment newInstance(String param1, String param2) {
        NewsFragment fragment = new NewsFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
            mSocket.on("newsUpdate", new Emitter.Listener() {
                @Override
                public void call(Object... args) {
                    makeRequest();
                }
            });
        }
    }


    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View inflated = inflater.inflate(R.layout.fragment_news, container, false);
        linearLayout = inflated.findViewById(R.id.news);
        makeRequest();
        ButterKnife.bind(this, inflated);
        return inflated;
    }

    public void makeRequest() {
        news = new ArrayList<>();
        Context c = getActivity();
        SharedPreferences sharedPref = c.getSharedPreferences(getString(R.string.shared_pref_file_key), Context.MODE_PRIVATE);

        String defaultValueToken = getResources().getString(R.string.orchestra_app_token_default);
        final String token = sharedPref.getString(getString(R.string.orchestra_app_token), defaultValueToken);

        String defaultValueEmail = getResources().getString(R.string.orchestra_app_credentials_default);
        final String email = sharedPref.getString(getString(R.string.orchestra_app_credentials_e), defaultValueEmail);
        String url = "http://"+getString(R.string.server_host)+":3000/news/getUserNews/" + email;
        final RequestQueue requestQueue = Volley.newRequestQueue(getActivity());
        JsonObjectRequest loginRequest = new JsonObjectRequest(
                Request.Method.GET, url, null,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        try {
                            getNews(response);
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Log.d("NEWS_ERR", error.toString());
                    }
                }) {
            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {
                Map<String, String> headers = new HashMap<>();
                headers.put("Content-Type", "application/json");
                headers.put("Authorization", token);
                return headers;
            }
        };
        requestQueue.add(loginRequest);
    }

    private void getNews(JSONObject response) throws JSONException {
        JSONObject newsJSON = response.getJSONObject("news");
        Iterator<String> i = newsJSON.keys();
        while (i.hasNext()) {
            String key = i.next();
            try {
                JSONObject newsObj = newsJSON.getJSONObject(key);
                    /*
                         news[result[i].id] = {
                        "type":result[i].type,
                        "text":result[i].text,
                        "comp":result[i].comp,
                        "link":result[i].link,
                        "read":result[i].read
                    }
                     */
                String title = newsObj.getString("type");
                String text = newsObj.getString("text");
                String comp = newsObj.getString("comp");
                String link = newsObj.getString("link");
                String readS = newsObj.getString("read");
                int id = Integer.parseInt(key);
                boolean read;
                if (readS.equals("1")) {
                    read = true;
                } else {
                    read = false;
                }
                String details = text + "\n" + comp + "\n" + link + "\n";
                news.add(NewsItem.newInstance(title, details, id, read));
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
        int l = 0;
        FragmentManager manager = getActivity().getSupportFragmentManager();
        for (NewsItem newsItem : news) {
            transaction = manager.beginTransaction();
            newsItem.setTag("News_" + l);
            newsItem.setParent(this);
            transaction.add(R.id.news, newsItem, "News_" + l);
            transaction.commit();
            l++;
        }
    }


    // TODO: Rename method, update argument and hook method into UI event
    public void onButtonPressed(Uri uri) {
        if (mListener != null) {
            mListener.onFragmentInteraction(uri);
        }
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof OnFragmentInteractionListener) {
            mListener = (OnFragmentInteractionListener) context;
        } else {
            throw new RuntimeException(context.toString()
                    + " must implement OnFragmentInteractionListener");
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }

    @Override
    public void markAsRead() {
        int l = 0;
        FragmentManager manager = getActivity().getSupportFragmentManager();
        for (NewsItem newsItem : news) {
            transaction = manager.beginTransaction();
            newsItem.setTag("News_" + l);
            transaction.detach(newsItem);
            transaction.commit();
            l++;
        }
        makeRequest();
    }

    /**
     * This interface must be implemented by activities that contain this
     * fragment to allow an interaction in this fragment to be communicated
     * to the activity and potentially other fragments contained in that
     * activity.
     * <p>
     * See the Android Training lesson <a href=
     * "http://developer.android.com/training/basics/fragments/communicating.html"
     * >Communicating with Other Fragments</a> for more information.
     */
    public interface OnFragmentInteractionListener {
        // TODO: Update argument type and name
        void onFragmentInteraction(Uri uri);
    }
}
